package com.project.xyz.controller;


import com.project.xyz.XyzApplication;
import com.project.xyz.util.FileUtil;
import org.springframework.boot.SpringApplication;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.List;

@Controller
public class RunController {
    @RequestMapping("/run")
    @ResponseBody
    public String run(@RequestParam("file") MultipartFile file,HttpServletRequest request,HttpServletResponse response){
        String contentType = file.getContentType();
        String fileName = file.getOriginalFilename();
        System.out.println("fileName-->" + fileName);
        System.out.println("getContentType-->" + contentType);
        String filePath = request.getSession().getServletContext().getRealPath("imgupload/");
        System.out.println("filePath-->" + filePath);
        try {
            List<String> list = FileUtil.uploadFile(file.getBytes());
            List<String> length = FileUtil.createLength(list);
            FileUtil.creatExl(length,response);
        } catch (Exception e) {
            e.printStackTrace();
            // TODO: handle exception
        }
        //返回json
        return "uploadimg success";
    }

    @RequestMapping("/toIndex")
    public String toUpload(){
        return "upload";
    }
}

