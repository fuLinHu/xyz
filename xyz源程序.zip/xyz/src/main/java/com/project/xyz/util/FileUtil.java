package com.project.xyz.util;

import com.project.xyz.XyzApplication;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.ss.util.CellRangeAddress;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.SpringApplication;

import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class FileUtil {
    protected static final Logger logger = LoggerFactory.getLogger(FileUtil.class);
    public static void uploadFile(byte[] file, String filePath, String fileName) throws Exception {
        InputStream inputStream = new ByteArrayInputStream(file);
        Workbook workbook = WorkbookFactory.create(inputStream);
        Sheet sheet = workbook.getSheetAt(0);
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {//获取每个Sheet表
            sheet = workbook.getSheetAt(i);
            for (int j = 0; j < sheet.getPhysicalNumberOfRows(); j++) {//获取每行
                Row row = sheet.getRow(j);
                String str = "";
                for (int k = 0; k < row.getPhysicalNumberOfCells(); k++) {//获取每个单元格
                    System.out.print(row.getCell(k)+"\t");
                    Object obj=row.getCell(k);
                    if(k==0){
                        str+=obj.toString().trim()+"_";
                    }else{
                        str+=obj.toString().trim()+",";
                    }
                }
                str=str.substring(0,str.length()-1);
                System.out.println("-----------------"+str);
                logger.info("-----------------"+str);
                list.add(str);
            }
        }
        /*File targetFile = new File(filePath);
        if(!targetFile.exists()){
            targetFile.mkdirs();
        }
        FileOutputStream out = new FileOutputStream(filePath+fileName);
        out.write(file);
        out.flush();
        out.close();*/
    }
    public static List<String> uploadFile(byte[] file) throws Exception {
        InputStream inputStream = new ByteArrayInputStream(file);
        Workbook workbook = WorkbookFactory.create(inputStream);
        Sheet sheet = workbook.getSheetAt(0);
        List<String> list = new ArrayList<String>();
        for (int i = 0; i < workbook.getNumberOfSheets(); i++) {//获取每个Sheet表
            sheet = workbook.getSheetAt(i);
            for (int j = 0; j < sheet.getPhysicalNumberOfRows(); j++) {//获取每行
                if(j==0){
                    continue;
                }
                Row row = sheet.getRow(j);
                if(row!=null){
                    String str = "";
                    for (int k = 0; k < row.getPhysicalNumberOfCells(); k++) {//获取每个单元格
                        Object obj=row.getCell(k);
                        if(k==0){
                            str+=obj.toString().trim()+"_";
                        }else{
                            str+=obj.toString().trim()+",";
                        }
                    }
                    str=str.substring(0,str.length()-1);
                    System.out.println("-----------------"+str);
                    logger.info("-----------------"+str);
                    list.add(str);
                }
            }
        }
        return list;
    }
    public static List<String> createLength(List<String> list){
        List<String> reslutList = new ArrayList<String>();
        for(int i=0;i<list.size();i++){
            for(int j=i+1;j<list.size();j++){
                String[] pointA=list.get(i).split("_");
                String[] pointB=list.get(j).split("_");
                String[] splitA = pointA[1].split(",");
                String[] splitB = pointB[1].split(",");
                Double x1=Double.parseDouble(splitA[0]);
                Double y1=Double.parseDouble(splitA[1]);
                Double z1=Double.parseDouble(splitA[2]);
                Double x2=Double.parseDouble(splitB[0]);
                Double y2=Double.parseDouble(splitB[1]);
                Double z2=Double.parseDouble(splitB[2]);
                Double X=Math.pow((x1-x2),2);
                Double Y=Math.pow((y1-y2),2);
                Double Z=Math.pow((z1-z2),2);
                Double result=Math.sqrt(X+Y+Z);
                BigDecimal bg = new BigDecimal(result).setScale(3, RoundingMode.UP);
                System.out.println(pointA[0]+"<<----->>"+pointB[0]+"-----------------"+bg.doubleValue());
                reslutList.add(pointA[0].substring(0,pointA[0].length()-2)+"->"+pointB[0].substring(0,pointB[0].length()-2)+"_"+bg.doubleValue());
            }
        }
        return reslutList;
    }
    public static void creatExl(List<String> list,HttpServletResponse response) throws Exception{
        Calendar calendar=Calendar.getInstance();
        SimpleDateFormat smft=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        String nowString=smft.format(calendar.getTime());
        response.reset(); // 清除buffer缓存
        // 指定下载的文件名
        response.setHeader("Content-Disposition", "attachment;filename=contacts" + nowString + ".xlsx");
        response.setContentType("application/vnd.ms-excel;charset=UTF-8");
        response.setHeader("Pragma", "no-cache");
        response.setHeader("Cache-Control", "no-cache");
        response.setDateHeader("Expires", 0);
        Workbook[] wbs = new Workbook[] { new HSSFWorkbook() };//, new XSSFWorkbook()
        OutputStream  output = response.getOutputStream();
        BufferedOutputStream bufferedOutPut = new BufferedOutputStream(output);
        bufferedOutPut.flush();
        int num=0;
        for (int i = 0; i < wbs.length; i++) {
            Workbook workbook = wbs[i];
            // 得到一个POI的工具类
            CreationHelper createHelper = workbook.getCreationHelper();
            // 在Excel工作簿中建一工作表，其名为缺省值, 也可以指定Sheet名称
            Sheet sheet = null;
            int m=0;
            List<String> sonList=new ArrayList<String>();
            for(int j=0;j<list.size();j++) {
                if (j % 5000 == 0) {
                    sonList=new ArrayList<String>();
                    List<String> strings =null;
                    if((5000 + m)>list.size()){
                        strings = list.subList(m,list.size());
                    }else{
                        strings = list.subList(m,5000 + m);
                    }
                    sonList.addAll(strings);
                    sheet = workbook.createSheet(num+"");
                    sheet.setColumnWidth(0,20 * 256);
                    sheet.setColumnWidth(1,20 * 256);
                    m=5000+m;
                    num++;
                    // Sheet sheet = workbook.createSheet("SheetName");
                    // 用于格式化单元格的数据
                    DataFormat format = workbook.createDataFormat();
                    // 设置字体
                    Font font = workbook.createFont();
                    //font.setFontHeightInPoints((short) 10); // 字体高度
                    font.setColor(Font.COLOR_RED); // 字体颜色
                    font.setFontName("黑体"); // 字体
                    font.setBoldweight(Font.BOLDWEIGHT_BOLD); // 宽度
                    font.setItalic(true); // 是否使用斜体
                    // font.setStrikeout(true); //是否使用划线
                    // 设置单元格类型
                    CellStyle cellStyle = workbook.createCellStyle();
                    cellStyle.setFont(font);
                    cellStyle.setAlignment(CellStyle.ALIGN_CENTER); // 水平布局：居中
                    cellStyle.setWrapText(true);
                    CellStyle cellStyle2 = workbook.createCellStyle();
                    cellStyle2.setDataFormat(format.getFormat("＃, ## 0.000"));
                    /*CellStyle cellStyle3 = workbook.createCellStyle();
                    cellStyle3.setDataFormat(format.getFormat("yyyy-MM-dd HH:mm:ss"));*/
                    // 添加单元格注释
                    // 创建Drawing对象,Drawing是所有注释的容器.
                    //Drawing drawing = sheet.createDrawingPatriarch();
                    // ClientAnchor是附属在WorkSheet上的一个对象， 其固定在一个单元格的左上角和右下角.
                    /*ClientAnchor anchor = createHelper.createClientAnchor();
                    // 设置注释位子
                    anchor.setRow1(0);
                    anchor.setRow2(2);
                    anchor.setCol1(0);
                    anchor.setCol2(2);
                    // 定义注释的大小和位置,详见文档
                    Comment comment = drawing.createCellComment(anchor);
                    // 设置注释内容
                    RichTextString str = createHelper.createRichTextString("Hello, World!");
                    comment.setString(str);
                    // 设置注释作者. 当鼠标移动到单元格上是可以在状态栏中看到该内容.
                    comment.setAuthor("H__D");*/
                    Row row0 = sheet.createRow(0);
                    Cell cell0 = row0.createCell((short) 0);
                    cell0.setCellValue(createHelper.createRichTextString("point"));// 设置单元格内容
                    cell0.setCellStyle(cellStyle);// 设置单元格样式
                    cell0.setCellType(Cell.CELL_TYPE_STRING);// 指定单元格格式：数值、公式或字符串
                    //cell0.setCellComment(comment);// 添加注释
                    Cell cell1 = row0.createCell((short) 1);
                    cell1.setCellValue(createHelper.createRichTextString("distance"));// 设置单元格内容
                    cell1.setCellStyle(cellStyle);// 设置单元格样式
                    cell1.setCellType(Cell.CELL_TYPE_STRING);// 指定单元格格式：数值、公式或字符串
                    //cell1.setCellComment(comment);// 添加注释
                    // 定义几行
                    for (int rownum = 0; rownum < sonList.size(); rownum++) {
                        String s = sonList.get(rownum);
                        String[] split = s.split("_");
                        // 创建行
                        Row row = sheet.createRow(rownum+1);
                        // 创建单元格
                        Cell cell = row.createCell((short) 0);
                        cell.setCellValue(createHelper.createRichTextString(split[0]));// 设置单元格内容
                        cell.setCellStyle(cellStyle);// 设置单元格样式
                        cell.setCellType(Cell.CELL_TYPE_STRING);// 指定单元格格式：数值、公式或字符串
                        //cell.setCellComment(comment);// 添加注释
                        // 格式化数据
                        Cell cell2 = row.createCell((short) 1);
                        cell2.setCellValue(split[1]);
                        cell2.setCellStyle(cellStyle2);
                        /*Cell cell3 = row.createCell((short) 3);
                        cell3.setCellValue(new Date());
                        cell3.setCellStyle(cellStyle3);*/
                       //sheet.autoSizeColumn((short) 0); // 调整第一列宽度
                        /* sheet.autoSizeColumn((short) 1); // 调整第二列宽度*/
                       /* sheet.autoSizeColumn((short) 2); // 调整第三列宽度
                        sheet.autoSizeColumn((short) 3); // 调整第四列宽度*/
                        System.out.println("rownum-->" + rownum);

                    }
                }
            }


            /*// 合并单元格
            sheet.addMergedRegion(new CellRangeAddress(1, // 第一行（0）
                    2, // last row（0-based）
                    1, // 第一列（基于0）
                    2 // 最后一列（基于0）
            ));*/

            // 保存
           // String filename = "D:\\SocialContact\\xyz\\workbook.xls";
           //File zip = new File(filename);
            /*List<String> fileNames = new ArrayList(); // 用于存放生成的文件名称s .xls
            fileNames.add("work.xls");
            File []srcfile = new File[fileNames.size()];
            for (int k = 0, n = fileNames.size(); k < n; k++) {
                srcfile[i] = new File(fileNames.get(i));
            }*/
            /*String path = Env.getProperty(Env.FILE_UPLOAD_URL);*/
           /* File zip = new File(path + "excel/"  + f + ".zip"); // 压缩文件*/
           // zipFiles(srcfile, zip);
            //FileInputStream inStream = new FileInputStream(zip);
            //byte[] buf = new byte[4096];
            // int readLength;
            //FileOutputStream out = new FileOutputStream(filename);
            workbook.write(bufferedOutPut);
            /*while ((readLength = inStream.read(buf)) != -1) {
                out.write(buf, 0, readLength);
                workbook.write(out);
            }
            inStream.close();*/
           /* if(!targetFile.exists()){
                targetFile.mkdirs();
            }*/
            /*if (workbook instanceof XSSFWorkbook) {
                filename = filename + "workbook.xlsx";
            }else{
                filename = filename + "workbook.xls";
            }*/
            bufferedOutPut.close();
        }
    }
    public static void zipFiles(java.io.File[] srcfile, java.io.File zipfile) {
        byte[] buf = new byte[1024];
        try {
            ZipOutputStream out = new ZipOutputStream(new FileOutputStream(
                    zipfile));
            for (int i = 0; i < srcfile.length; i++) {
                FileInputStream in = new FileInputStream(srcfile[i]);
                out.putNextEntry(new ZipEntry(srcfile[i].getName()));
                int len;
                while ((len = in.read(buf)) > 0) {
                    out.write(buf, 0, len);
                }
                out.closeEntry();
                in.close();
            }
            out.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
